package graphic;

public interface Updatable {
	public void Update();
}
