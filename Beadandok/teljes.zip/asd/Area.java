package graphic;

/**
 * Egy ter�letet reprezent�l a mez� n�zet�n.
 */
public  class Area{
	public double x, y, w, h;
	public Area(double x, double y, double w, double h) {
		this.x = x;
		this.y = y;
		this.w = w;
		this.h = h;
	}
}