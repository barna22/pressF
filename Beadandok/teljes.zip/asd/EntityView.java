package graphic;

import java.awt.image.BufferedImage;

/**
 * Interface az entity-k view oszt�lyainak
 */
public interface EntityView	{
	public BufferedImage GetImage();
}
