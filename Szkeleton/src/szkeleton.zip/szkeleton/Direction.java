package szkeleton;

public enum Direction {
	UP,
	DOWN,
	LEFT,
	RIGHT
}
